module.exports = {
  "css": {
    "modules": true
  },
  "transpileDependencies": [
    "vuetify"
  ]
}