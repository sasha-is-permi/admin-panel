  <template>
     <v-main>
        <div class="div1">     
           <p class="text-center"> Процессы </p>
        </div>
     </v-main>
  </template>

<script>


export default {



}


</script>

<style scoped>
  .text-center {
    font-size:18px;
    text-align:center;
    color:green;
  }
  .div1{
    height:480px;
    display:flex;
    justify-content:center;
    margin-top:50px;
   /* align-items:center; */
  }

</style>